import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBLQti6kUeEZVaGw4xMKpOMiPUif5Zzh-M",
  authDomain: "projeto-puc-florescer-app.firebaseapp.com",
  projectId: "projeto-puc-florescer-app",
  storageBucket: "projeto-puc-florescer-app.firebasestorage.app",
  messagingSenderId: "154644205214",
  appId: "1:154644205214:web:37b84788370370e80db58f",
};

export const FIREBASE_APP = initializeApp(firebaseConfig);
export const FIREBASE_AUTH = getAuth(FIREBASE_APP);
export const FIREBASE_DB = getFirestore(FIREBASE_APP);
