// jest.setup.js

jest.mock("expo/src/winter/installGlobal.ts", () => ({}));
jest.mock("expo/src/winter/runtime.native.ts", () => ({}));
