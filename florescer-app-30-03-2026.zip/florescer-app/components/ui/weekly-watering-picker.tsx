import DateTimePicker from "@react-native-community/datetimepicker";
import { useState } from "react";
import { Text, TouchableOpacity, View } from "react-native";

const daysOfWeek = [
  { key: "mon", label: "Segunda" },
  { key: "tue", label: "Terça" },
  { key: "wed", label: "Quarta" },
  { key: "thu", label: "Quinta" },
  { key: "fri", label: "Sexta" },
  { key: "sat", label: "Sábado" },
  { key: "sun", label: "Domingo" },
];

export default function WeeklyWateringPicker({ value, onChange }) {
  const [selectedDays, setSelectedDays] = useState(value?.days ?? []);
  const [time, setTime] = useState(value?.time ?? "08:00");
  const [showPicker, setShowPicker] = useState(false);

  const toggleDay = (dayKey: string) => {
    let newDays;
    if (selectedDays.includes(dayKey)) {
      newDays = selectedDays.filter((d) => d !== dayKey);
    } else {
      newDays = [...selectedDays, dayKey];
    }
    setSelectedDays(newDays);
    onChange({ days: newDays, time });
  };

  const onTimeChange = (_, selected) => {
    setShowPicker(false);
    if (selected) {
      const h = selected.getHours().toString().padStart(2, "0");
      const m = selected.getMinutes().toString().padStart(2, "0");
      const newTime = `${h}:${m}`;
      setTime(newTime);
      onChange({ days: selectedDays, time: newTime });
    }
  };

  return (
    <View className="mt-4">
      <Text className="text-lg font-semibold mb-2">Dias de Rega</Text>

      <View className="flex-row flex-wrap gap-2">
        {daysOfWeek.map((d) => (
          <TouchableOpacity
            key={d.key}
            onPress={() => toggleDay(d.key)}
            className={`px-3 py-2 rounded-lg 
            ${selectedDays.includes(d.key) ? "bg-emerald-600" : "bg-gray-300"}`}
          >
            <Text className="text-white">{d.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text className="text-lg font-semibold mt-4 mb-1">Horário</Text>

      <TouchableOpacity
        onPress={() => setShowPicker(true)}
        className="bg-emerald-500 p-3 rounded-lg w-32"
      >
        <Text className="text-white text-center">{time}</Text>
      </TouchableOpacity>

      {showPicker && (
        <DateTimePicker
          mode="time"
          value={new Date()}
          onChange={onTimeChange}
        />
      )}
    </View>
  );
}
