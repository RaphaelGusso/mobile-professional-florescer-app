import { colors } from "@/constants/colors";
import { DrawerContentScrollView, DrawerItem } from "@react-navigation/drawer";
import { Leaf, LogOut } from "lucide-react-native";
import { Text, View } from "react-native";

function CustomDrawerContent(props: any) {
  const userName = "Raphael Silva";
  const version = "2025.0.0.0.1";
  const dateTime = new Date().toLocaleString();

  return (
    <DrawerContentScrollView {...props} contentContainerStyle={{ flex: 1 }}>
      {/* Cabeçalho customizado */}
      <View
        style={{ padding: 16, borderBottomWidth: 1, borderBottomColor: "#ccc" }}
      >
        <Text style={{ color: colors.white, fontWeight: "bold", fontSize: 18 }}>
          {userName}
        </Text>
        <Text style={{ color: colors.white, marginTop: 4 }}>{dateTime}</Text>
        <Text style={{ color: colors.white, marginTop: 4 }}>
          Versão {version}
        </Text>
      </View>

      {/* Botões do drawer */}
      <DrawerItem
        label="Plantas"
        onPress={() => props.navigation.navigate("flourish")}
        icon={({ color, size }) => <Leaf color={color} size={size} />}
      />

      <DrawerItem
        label="Sair"
        onPress={() => {
          // logout
        }}
        icon={({ color, size }) => <LogOut color={color} size={size} />}
      />
    </DrawerContentScrollView>
  );
}
