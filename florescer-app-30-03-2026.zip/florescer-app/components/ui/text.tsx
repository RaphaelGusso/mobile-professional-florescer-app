import { cn } from "@/lib/utils";
import React from "react";
import { Text as RNText, TextProps } from "react-native";

interface Props extends TextProps {
  className?: string;
}

export const Text = React.forwardRef<RNText, Props>(
  ({ className, style, ...props }, ref) => {
    return (
      <RNText
        ref={ref}
        style={style}
        className={cn("text-base text-foreground web:select-text", className)}
        {...props}
      />
    );
  }
);

Text.displayName = "Text";
