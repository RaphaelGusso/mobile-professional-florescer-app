export const colors = {
  primary: "#059669",
  white: "#fff",
  text: "#11181C",
};
