import { FIREBASE_AUTH } from "@/firebaseConfig";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from "@firebase/auth";
import { useRouter } from "expo-router";
import { FirebaseError } from "firebase/app";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Image,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import Toast from "react-native-toast-message";
import florescerLogo from "../assets/images/florescer-app-logo.png";

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoadingSignIn, setIsLoadingSignIn] = useState(false);
  const [isLoadingSignUp, setIsLoadingSignUp] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const visible = email.trim() !== "" && password.trim() !== "";
    setIsVisible(visible);
  }, [email, password]);

  const auth = FIREBASE_AUTH;

  async function signIn() {
    try {
      setIsLoadingSignIn(true);
      await signInWithEmailAndPassword(auth, email, password);
      router.replace("/(protected)/flourish");
    } catch (error) {
      if (error instanceof FirebaseError) {
        Toast.show({
          type: "error",
          text1: "Credenciais inválidas!",
        });
      } else {
        Toast.show({
          type: "error",
          text1: "Erro ao cadastrar",
          text2: "Ocorreu um erro inesperado, Entre em contato com o suporte",
        });
      }
    } finally {
      setIsLoadingSignIn(false);
    }
  }

  async function signUp() {
    try {
      setIsLoadingSignUp(true);
      await createUserWithEmailAndPassword(auth, email, password);

      Toast.show({
        type: "success",
        text1: "Email cadastrado com sucesso!",
      });
    } catch (error) {
      if (error instanceof FirebaseError) {
        if (error.code === "auth/email-already-in-use") {
          Toast.show({
            type: "error",
            text1: "Email já cadastrado",
            text2: "Este email já está em uso. Tente fazer login.",
          });
        } else if (error.code === "auth/weak-password") {
          Toast.show({
            type: "error",
            text1: "Senha fraca",
            text2: "A senha precisa ter pelo menos 6 caracteres.",
          });
        } else if (error.code === "auth/invalid-email") {
          Toast.show({
            type: "error",
            text1: "Email inválido",
            text2: "Por favor, verifique o email digitado.",
          });
        }
      } else {
        Toast.show({
          type: "error",
          text1: "Erro ao cadastrar",
          text2: "Ocorreu um erro inesperado, Entre em contato com o suporte",
        });
      }
    } finally {
      setIsLoadingSignUp(false);
    }
  }

  return (
    <SafeAreaView className="flex-1 pt-16 items-center justify-start bg-emerald-50">
      <View className="mb-4">
        <Text className="font-bold text-gray-800">Versão 2025.0.0.0.1</Text>
      </View>

      <View className=" w-4/5 items-center">
        <Image className="mb-2" source={florescerLogo} alt="Florescer Logo" />
        <TextInput
          className="my-2 h-12 w-full rounded-md border border-gray-300 p-3 text-black"
          value={email}
          placeholder="Email"
          autoCapitalize="none"
          keyboardType="email-address"
          onChangeText={(text) => setEmail(text)}
        />

        <TextInput
          className="my-2 h-12 w-full rounded-md border border-gray-300 p-3 text-black"
          value={password}
          placeholder="Senha"
          autoCapitalize="none"
          secureTextEntry={true}
          onChangeText={(text) => setPassword(text)}
        />
      </View>

      <View className="w-4/5 items-center">
        <TouchableOpacity
          onPress={signIn}
          disabled={!isVisible}
          className={`p-3 rounded-xl shadow-md flex-row items-center justify-center w-full ${
            isVisible ? "bg-emerald-600" : "bg-emerald-200"
          }`}
        >
          {isLoadingSignIn ? (
            <ActivityIndicator size="small" color="#FFFFFF" />
          ) : (
            <Text className="text-2xl font-semibold text-white">Login</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          onPress={signUp}
          className="p-3 mt-3 rounded-xl border border-emerald-600 flex-row items-center justify-center w-full"
        >
          {isLoadingSignUp ? (
            <ActivityIndicator size="small" color="#059669" />
          ) : (
            <Text className="text-2xl font-semibold text-emerald-600">
              Cadastrar
            </Text>
          )}
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
