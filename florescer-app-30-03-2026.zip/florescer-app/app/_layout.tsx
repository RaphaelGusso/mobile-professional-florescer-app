import { SplashScreen, Stack } from "expo-router";
import { useEffect } from "react";
import "react-native-reanimated";
import Toast from "react-native-toast-message";
import "../global.css";

SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  return (
    <>
      <InitialLayout />
      <Toast />
    </>
  );
}

function InitialLayout() {
  useEffect(() => {
    SplashScreen.hideAsync();
  }, []);

  return (
    <Stack>
      <Stack.Screen
        name="(protected)"
        options={{ headerShown: false, animation: "none" }}
      />
      <Stack.Screen
        name="index"
        options={{ headerShown: false, animation: "none" }}
      />
    </Stack>
  );
}
