import WeeklyWateringPicker from "@/components/ui/weekly-watering-picker";
import { FIREBASE_DB } from "@/firebaseConfig";
import {
  requestNotificationPermission,
  schedulePlantNotifications,
} from "@/utils/notifications";
import { router, useLocalSearchParams, useNavigation } from "expo-router";
import { getAuth } from "firebase/auth";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import { useEffect, useState } from "react";
import { Text, TextInput, TouchableOpacity } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import Toast from "react-native-toast-message";

export default function UpdatePlant() {
  const { plantId } = useLocalSearchParams<{ plantId?: string }>();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [watering, setWatering] = useState({ days: [], time: "08:00" });
  const [loading, setLoading] = useState(false);
  const auth = getAuth();
  const user = auth.currentUser;
  const navigation = useNavigation();

  //Setei o cabeçalho aqui pois por algum motivo no _layout ele não alterava
  useEffect(() => {
    navigation.setOptions({
      title: "Alterar uma Planta",
    });
  }, []);

  useEffect(() => {
    if (!plantId) return;

    const fetchPlant = async () => {
      setLoading(true);
      try {
        const docRef = doc(FIREBASE_DB, "plants", plantId);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setName(data.name);
          setDescription(data.description);
          setWatering(data.watering);
        } else {
          Toast.show({ type: "error", text1: "Planta não encontrada" });
          router.back();
        }
      } catch (error) {
        Toast.show({
          type: "error",
          text1: `Erro ao carregar planta ${error}`,
        });
      } finally {
        setLoading(false);
      }
    };

    fetchPlant();
  }, [plantId]);

  async function handleSave() {
    if (!user) {
      Toast.show({
        type: "error",
        text1: "Você precisa estar logado para salvar uma planta",
      });
      return;
    }
    if (!name || !description || !watering) {
      Toast.show({ type: "error", text1: "Preencha todos os campos" });
      return;
    }

    try {
      if (plantId) {
        const docRef = doc(FIREBASE_DB, "plants", plantId);
        await updateDoc(docRef, { name, description, watering });
        Toast.show({ type: "success", text1: `Planta ${name} atualizada!` });
      } else {
        Toast.show({ type: "error", text1: "Planta não encontrada" });
      }

      const granted = await requestNotificationPermission();

      if (granted) {
        await schedulePlantNotifications(
          `Hora da rega da ${name}`,
          "Não esqueça de regar sua planta!",
          watering.days,
          parseInt(watering.time.split(":")[0]),
          parseInt(watering.time.split(":")[1]),
          plantId as string
        );
      } else {
        Toast.show({
          type: "info",
          text1: "Permissão para notificações negada",
          text2: "Você não receberá lembretes de rega",
        });
      }

      router.back();
    } catch (error) {
      Toast.show({ type: "error", text1: `Erro ao salvar planta ${error}` });
    }
  }

  if (loading) {
    return (
      <SafeAreaView className="flex-1 items-center justify-center bg-emerald-50">
        <Text>Carregando planta...</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 px-6 pt-6 bg-emerald-50">
      <Text className="text-2xl font-bold text-emerald-700 mb-4">
        {plantId ? "Editar Planta" : "Cadastrar Planta"}
      </Text>

      <TextInput
        placeholder="Nome da planta"
        value={name}
        onChangeText={setName}
        className="border p-3 mb-4 rounded-md bg-white"
      />

      <TextInput
        placeholder="Descrição"
        value={description}
        onChangeText={setDescription}
        className="border p-3 mb-4 rounded-md bg-white"
      />

      <Text className="text-lg font-semibold mb-2">
        Selecione os dias da semana e o horário que deseja regar a planta
      </Text>

      <WeeklyWateringPicker
        value={watering}
        onChange={(newValue) => setWatering(newValue)}
      />

      <TouchableOpacity
        onPress={handleSave}
        className="bg-emerald-600 p-3 rounded-md items-center mt-3"
      >
        <Text className="text-white font-bold text-lg">Atualizar</Text>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() => navigation.goBack()}
        className="mt-3 flex-row items-center justify-center bg-emerald-600 p-3 rounded-md"
      >
        <Text className="text-white">Voltar</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
