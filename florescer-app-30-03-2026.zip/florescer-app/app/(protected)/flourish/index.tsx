import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { colors } from "@/constants/colors";
import { FIREBASE_DB } from "@/firebaseConfig";
import { Feather } from "@expo/vector-icons";
import { useIsFocused } from "@react-navigation/native";
import { router } from "expo-router";
import { collection, deleteDoc, doc, getDocs } from "firebase/firestore";
import { useEffect, useState } from "react";
import { FlatList, Text, TouchableOpacity, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import Toast from "react-native-toast-message";

type Plant = {
  id: string;
  name: string;
  description: string;
  watering: string;
};

async function deletePlant(plantId: string) {
  try {
    await deleteDoc(doc(FIREBASE_DB, "plants", plantId));
    Toast.show({
      type: "success",
      text1: `Planta excluida com sucesso`,
    });
  } catch (error) {
    Toast.show({
      type: "error",
      text1: `Erro ao excluir planta: ${error}`,
    });
  }
}

export default function FlourishScreen() {
  const [plants, setPlants] = useState<Plant[]>([]);
  const [loading, setLoading] = useState(true);
  const [filteredPlants, setFilteredPlants] = useState<Plant[]>([]);
  const [searchText, setSearchText] = useState("");
  const isFocused = useIsFocused();

  useEffect(() => {
    const fetchPlants = async () => {
      setLoading(true);
      try {
        const querySnapshot = await getDocs(collection(FIREBASE_DB, "plants"));
        const plantsData: Plant[] = querySnapshot.docs.map((doc) => ({
          id: doc.id,
          ...(doc.data() as Omit<Plant, "id">),
        }));
        setPlants(plantsData);
      } catch (error) {
        Toast.show({
          type: "error",
          text1: `Erro ao buscar plantas: ${error}`,
        });
      } finally {
        setLoading(false);
      }
    };

    fetchPlants();
  }, [isFocused]);

  useEffect(() => {
    if (!searchText) {
      setFilteredPlants(plants);
    } else {
      const filtered = plants.filter((plant) =>
        plant.name.toLowerCase().includes(searchText.toLowerCase()),
      );
      setFilteredPlants(filtered);
    }
  }, [searchText, plants]);

  if (loading) {
    return (
      <SafeAreaView className="flex-1 items-center justify-center">
        <Text>Carregando plantas...</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView className="flex-1 mx-6" edges={["bottom"]}>
      <View className="mt-6 w-full flex-row items-center border border-slate-300 rounded-md px-3">
        <Feather name="search" size={20} color={colors.primary} />
        <Input
          className="border-0 rounded-none flex-1"
          placeholder="Buscar"
          value={searchText}
          onChangeText={setSearchText}
        />
      </View>

      <TouchableOpacity
        className="p-3 mt-3 rounded-xl bg-emerald-600 flex-row items-center justify-center w-full"
        onPress={() => router.push("/flourish/create")}
      >
        <Feather name="plus" size={20} color="white" className="mr-2" />
        <Text className="text-white font-bold text-lg">Cadastrar Planta</Text>
      </TouchableOpacity>

      <FlatList
        className="mt-3"
        data={filteredPlants}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => router.push(`/flourish/${item.id}`)}>
            <Card className="mt-4">
              <CardHeader>
                <CardTitle className="text-2xl text-green-800 mb-2">
                  {item.name}
                </CardTitle>
                <CardDescription className="mb-2 text-xl">
                  {item.description}
                </CardDescription>
                <CardDescription className="text-xl">
                  agendado para regar: {item.watering.time} (
                  {item.watering.days.join(", ")})
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Text className="text-emerald-700">
                  Clique para ver mais detalhes.
                </Text>
                <TouchableOpacity
                  onPress={async () => {
                    await deletePlant(item.id);
                    setPlants((prev) => prev.filter((p) => p.id !== item.id));
                  }}
                  testID="btn-delete"
                  className="p-2"
                >
                  <Feather name="trash" size={22} color="red" />
                </TouchableOpacity>
              </CardContent>
            </Card>
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  );
}
