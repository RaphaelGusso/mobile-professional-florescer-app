import { colors } from "@/constants/colors";
import { Stack } from "expo-router";

export default function FlourishLayout() {
  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: colors.primary },
        headerTintColor: colors.white,
        headerTitleStyle: { fontWeight: "bold", fontSize: 20 },
      }}
    >
      <Stack.Screen
        name="index"
        options={{
          title: "Plantas",
          headerShown: true,
          headerLeft: undefined,
        }}
      />

      <Stack.Screen
        name="[flourishId]"
        options={{
          title: "Detalhes da Planta",
          animation: "slide_from_right",
          headerShown: true,
        }}
      />
    </Stack>
  );
}
