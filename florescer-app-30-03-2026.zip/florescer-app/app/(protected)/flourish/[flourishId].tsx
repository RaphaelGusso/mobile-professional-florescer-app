import { FIREBASE_DB } from "@/firebaseConfig";
import { useIsFocused } from "@react-navigation/native";
import { router, useLocalSearchParams, useNavigation } from "expo-router";
import { doc, getDoc } from "firebase/firestore";
import { useEffect, useLayoutEffect, useState } from "react";
import { Image, Text, TouchableOpacity, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import Toast from "react-native-toast-message";

export default function FlourishDetails() {
  const { flourishId } = useLocalSearchParams<{ flourishId: string }>();
  const navigation = useNavigation();
  const [plant, setPlant] = useState<{
    name: string;
    description: string;
    watering: { days: string[]; time: string };
    photo?: string | null;
  } | null>(null);

  const isFocused = useIsFocused();

  useLayoutEffect(() => {
    navigation.setOptions({
      title: "Detalhes da Planta",
    });
  }, []);

  useEffect(() => {
    if (!flourishId) return;

    const fetchPlant = async () => {
      try {
        const docRef = doc(FIREBASE_DB, "plants", flourishId);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
          setPlant(
            docSnap.data() as {
              name: string;
              description: string;
              watering: { days: string[]; time: string };
              photo?: string | null;
            }
          );
        } else {
          Toast.show({ type: "error", text1: "Nenhuma planta encontrada!" });
        }
      } catch (error) {
        Toast.show({ type: "error", text1: `Erro ao buscar planta: ${error}` });
      }
    };

    fetchPlant();
  }, [flourishId, isFocused]);

  return (
    <SafeAreaView className="flex-1 items-center justify-center bg-emerald-50">
      <View className="p-6 bg-white rounded-2xl shadow-md w-4/5">
        {plant ? (
          <>
            {plant.photo && (
              <Image
                source={{ uri: `data:image/jpeg;base64,${plant.photo}` }}
                className="w-full h-56 rounded-md mb-4"
              />
            )}

            <Text className="text-2xl font-bold text-emerald-700 mb-2">
              {plant.name}
            </Text>

            <Text className="text-gray-700 text-lg">{plant.description}</Text>

            <Text className="text-gray-700 text-lg">
              Agendado para regar: {plant.watering.time} (
              {plant.watering.days.join(", ")})
            </Text>
          </>
        ) : (
          <Text>Carregando dados da planta...</Text>
        )}

        <TouchableOpacity
          onPress={() => router.push(`/flourish/update?plantId=${flourishId}`)}
          className="mt-6 flex-row items-center justify-center bg-emerald-400 p-3 rounded-md"
        >
          <Text className="text-white">Editar</Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => navigation.goBack()}
          className="mt-3 flex-row items-center justify-center bg-emerald-600 p-3 rounded-md"
        >
          <Text className="text-white">Voltar</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}
