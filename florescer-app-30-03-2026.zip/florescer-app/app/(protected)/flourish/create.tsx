import WeeklyWateringPicker from "@/components/ui/weekly-watering-picker";
import { FIREBASE_DB } from "@/firebaseConfig";
import {
  requestNotificationPermission,
  schedulePlantNotifications,
} from "@/utils/notifications";
import { router, useFocusEffect, useNavigation } from "expo-router";
import { getAuth } from "firebase/auth";
import { addDoc, collection } from "firebase/firestore";
import { useCallback, useEffect, useState } from "react";
import { Text, TextInput, TouchableOpacity } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import Toast from "react-native-toast-message";

export default function CreatePlant() {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [watering, setWatering] = useState({ days: [], time: "08:00" });
  const auth = getAuth();
  const user = auth.currentUser;
  const navigation = useNavigation();

  //Setei o cabeçalho aqui pois por algum motivo no _layout ele não alterava
  useEffect(() => {
    navigation.setOptions({
      title: "Cadastrar uma Planta",
    });
  }, []);

  useFocusEffect(
    useCallback(() => {
      // reset automático sempre que entrar na tela
      setName("");
      setDescription("");
      setWatering({ days: [], time: "08:00" });
    }, [])
  );

  async function handleSave() {
    if (!user) {
      Toast.show({
        type: "error",
        text1: "Você precisa estar logado para cadastrar uma planta",
      });
      return;
    }
    if (!name || !description) {
      Toast.show({
        type: "error",
        text1: "Preencha todos os campos",
      });
      return;
    }

    try {
      const docRef = await addDoc(collection(FIREBASE_DB, "plants"), {
        name,
        description,
        watering,
        createdBy: user.uid,
        createdAt: new Date(),
      });

      Toast.show({
        type: "success",
        text1: `Planta ${name} cadastrada com sucesso`,
      });

      const plantId = docRef.id;

      const granted = await requestNotificationPermission();

      if (granted) {
        await schedulePlantNotifications(
          `Hora da rega da planta ${name}`,
          "Não esqueça de regar sua planta!",
          watering.days,
          parseInt(watering.time.split(":")[0]),
          parseInt(watering.time.split(":")[1]),
          plantId
        );
      } else {
        Toast.show({
          type: "info",
          text1: "Permissão para notificações negada",
          text2: "Você não receberá lembretes de rega",
        });
      }

      router.back();
    } catch (error) {
      console.log(error);
      Toast.show({
        type: "error",
        text1: "Erro ao cadastrar planta",
        text2: error as string,
      });
    }
  }

  return (
    <SafeAreaView className="flex-1 px-6 pt-6 bg-emerald-50">
      <Text className="text-2xl font-bold text-emerald-700 mb-4">
        Cadastrar Planta
      </Text>

      <TextInput
        placeholder="Nome da planta"
        value={name}
        onChangeText={setName}
        className="border p-3 mb-4 rounded-md bg-white"
      />

      <TextInput
        placeholder="Descrição"
        value={description}
        onChangeText={setDescription}
        className="border p-3 mb-4 rounded-md bg-white"
      />

      <Text className="text-lg font-semibold mb-2">
        Selecione os dias da semana e o horário que deseja regar a planta
      </Text>

      <WeeklyWateringPicker
        value={watering}
        onChange={(newValue) => setWatering(newValue)}
      />

      <TouchableOpacity
        onPress={handleSave}
        className="bg-emerald-600 p-3 rounded-md items-center mt-3"
      >
        <Text className="text-white font-bold text-lg">Salvar</Text>
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() => navigation.goBack()}
        className="mt-3 flex-row items-center justify-center bg-emerald-600 p-3 rounded-md"
      >
        <Text className="text-white">Voltar</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
