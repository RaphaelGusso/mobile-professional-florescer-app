import { colors } from "@/constants/colors";
import { FIREBASE_AUTH } from "@/firebaseConfig";
import { DrawerContentScrollView, DrawerItem } from "@react-navigation/drawer";
import { useRouter } from "expo-router";
import { Drawer } from "expo-router/drawer";
import { signOut } from "firebase/auth";
import { Leaf, LogOut } from "lucide-react-native";
import { useEffect, useState } from "react";
import { Image, Text, View } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import florescerLogo from "../../assets/images/florescer-app-logo.png";

export default function ProtectedLayout() {
  const router = useRouter();
  const [userEmail, setUserEmail] = useState<string | null>(null);

  useEffect(() => {
    const user = FIREBASE_AUTH.currentUser;
    if (user) {
      setUserEmail(user.email);
    }
  }, []);

  async function handleLogout() {
    await signOut(FIREBASE_AUTH);
    router.replace("/");
  }

  return (
    <GestureHandlerRootView className="flex-1">
      <Drawer
        screenOptions={{
          headerStyle: { backgroundColor: colors.primary },
          headerTintColor: colors.white,
          drawerStyle: { backgroundColor: colors.primary },
          drawerActiveTintColor: colors.white,
          drawerInactiveTintColor: "#d1fae5",
          drawerLabelStyle: { fontWeight: "bold", fontSize: 16 },
        }}
        drawerContent={(props) => (
          <DrawerContentScrollView
            {...props}
            contentContainerStyle={{ flex: 1 }}
          >
            <View className="px-4 py-6 border-b border-white items-center">
              <Image
                source={florescerLogo}
                alt="Florescer Logo"
                className="w-48 h-64 mb-1 rounded-full"
              />
              <Text className="text-white text-2xl font-bold -mb-1">
                {userEmail ?? "Usuário"}
              </Text>
              <Text className="text-white text-xl mt-1">
                {new Date().toLocaleString()}
              </Text>
              <Text className="text-white text-xl mt-1">
                Versão 2025.0.0.0.1
              </Text>
            </View>
            <DrawerItem
              label="Plantas"
              onPress={() => props.navigation.navigate("flourish/index")}
              icon={({ color, size }) => <Leaf color={color} size={size} />}
              activeTintColor={colors.white}
              inactiveTintColor="#d1fae5"
            />

            <DrawerItem
              label=""
              onPress={() => {}}
              style={{ flex: 1, opacity: 0 }}
            />

            <DrawerItem
              label="Sair"
              onPress={handleLogout}
              icon={({ color, size }) => <LogOut color={color} size={size} />}
              activeTintColor={colors.white}
              inactiveTintColor="#d1fae5"
            />
          </DrawerContentScrollView>
        )}
      >
        <Drawer.Screen
          name="flourish/index"
          options={{
            drawerLabel: "Plantas",
            title: "Plantas",
          }}
        />
      </Drawer>
    </GestureHandlerRootView>
  );
}
