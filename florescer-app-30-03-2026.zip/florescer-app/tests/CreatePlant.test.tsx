import CreatePlant from "@/app/(protected)/flourish/create";
import {
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react-native";
import { router } from "expo-router";
import { addDoc } from "firebase/firestore";
import React from "react";
import Toast from "react-native-toast-message";

jest.mock("firebase/auth", () => ({
  getAuth: jest.fn(() => ({
    currentUser: { uid: "usuario-teste-123" },
  })),
}));

jest.mock("firebase/firestore", () => ({
  __esModule: true,
  collection: jest.fn(),
  addDoc: jest.fn(),
}));

jest.mock("@/firebaseConfig", () => ({
  FIREBASE_DB: {},
}));

const mockGoBack = jest.fn();
jest.mock("expo-router", () => ({
  __esModule: true,
  router: { back: jest.fn() },
  useNavigation: () => ({
    setOptions: jest.fn(),
    goBack: mockGoBack,
  }),
  useFocusEffect: jest.fn(),
}));

jest.mock("@/utils/notifications", () => ({
  requestNotificationPermission: jest.fn(() => Promise.resolve(true)),
  schedulePlantNotifications: jest.fn(() => Promise.resolve()),
}));

jest.mock("react-native-toast-message", () => ({
  show: jest.fn(),
}));

jest.mock("@/components/ui/weekly-watering-picker", () => {
  const { View } = require("react-native");
  return () => <View testID="weekly-picker-mock" />;
});

describe("Tela <CreatePlant />", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("deve exibir um erro se tentar salvar sem preencher os campos", () => {
    render(<CreatePlant />);

    const botaoSalvar = screen.getByText("Salvar");
    fireEvent.press(botaoSalvar);

    expect(Toast.show).toHaveBeenCalledWith({
      type: "error",
      text1: "Preencha todos os campos",
    });
  });

  it("deve cadastrar a planta com sucesso e voltar de tela", async () => {
    (addDoc as jest.Mock).mockResolvedValueOnce({ id: "id-planta-123" });

    render(<CreatePlant />);

    fireEvent.changeText(
      screen.getByPlaceholderText("Nome da planta"),
      "Espada de São Jorge",
    );
    fireEvent.changeText(
      screen.getByPlaceholderText("Descrição"),
      "Planta resistente",
    );

    fireEvent.press(screen.getByText("Salvar"));

    await waitFor(() => {
      expect(addDoc).toHaveBeenCalled();
      expect(Toast.show).toHaveBeenCalledWith({
        type: "success",
        text1: "Planta Espada de São Jorge cadastrada com sucesso",
      });
      expect(router.back).toHaveBeenCalled();
    });
  });

  it("deve exibir um erro caso o Firebase falhe ao salvar", async () => {
    (addDoc as jest.Mock).mockRejectedValueOnce("Erro de permissão no banco");

    render(<CreatePlant />);

    fireEvent.changeText(
      screen.getByPlaceholderText("Nome da planta"),
      "Cacto",
    );
    fireEvent.changeText(
      screen.getByPlaceholderText("Descrição"),
      "Pouca água",
    );

    fireEvent.press(screen.getByText("Salvar"));

    await waitFor(() => {
      expect(Toast.show).toHaveBeenCalledWith({
        type: "error",
        text1: "Erro ao cadastrar planta",
        text2: "Erro de permissão no banco",
      });
    });
  });

  it("deve voltar para a tela anterior ao clicar no botão Voltar", () => {
    render(<CreatePlant />);

    const botaoVoltar = screen.getByText("Voltar");
    fireEvent.press(botaoVoltar);

    expect(mockGoBack).toHaveBeenCalled();
  });
});
