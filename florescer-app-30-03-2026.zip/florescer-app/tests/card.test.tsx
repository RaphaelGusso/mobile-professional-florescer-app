import { render, screen } from "@testing-library/react-native";
import React from "react";
import { Text, View } from "react-native";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "../components/ui/card";

describe("Componentes de Card", () => {
  it("deve renderizar a estrutura completa do card corretamente", () => {
    render(
      <Card>
        <CardHeader>
          <CardTitle>Título do Card</CardTitle>
          <CardDescription>Descrição do Card</CardDescription>
        </CardHeader>
        <CardContent>
          <Text>Conteúdo Principal</Text>
        </CardContent>
        <CardFooter>
          <Text>Rodapé</Text>
        </CardFooter>
      </Card>,
    );

    expect(screen.getByText("Título do Card")).toBeTruthy();
    expect(screen.getByText("Descrição do Card")).toBeTruthy();
    expect(screen.getByText("Conteúdo Principal")).toBeTruthy();
    expect(screen.getByText("Rodapé")).toBeTruthy();
  });

  it("deve aplicar estilos customizados via className através do cn", () => {
    render(
      <Card testID="card-id" className="bg-red-500">
        <CardContent>
          <Text>Teste de Estilo</Text>
        </CardContent>
      </Card>,
    );

    const card = screen.getByTestId("card-id");
    expect(card).toBeTruthy();
  });

  it("deve renderizar CardTitle como um componente de texto", () => {
    render(<CardTitle>Texto de Título</CardTitle>);
    const title = screen.getByText("Texto de Título");

    expect(title.props.children).toBe("Texto de Título");
  });

  it("deve permitir a renderização de elementos filhos complexos no CardContent", () => {
    render(
      <CardContent>
        <View testID="inner-view" />
      </CardContent>,
    );

    expect(screen.getByTestId("inner-view")).toBeTruthy();
  });
});
