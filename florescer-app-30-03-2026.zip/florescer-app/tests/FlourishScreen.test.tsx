import {
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react-native";
import { deleteDoc, getDocs } from "firebase/firestore";
import React from "react";
import Toast from "react-native-toast-message";
import FlourishScreen from "../app/(protected)/flourish/index";

jest.mock("firebase/firestore", () => ({
  __esModule: true,
  collection: jest.fn(),
  getDocs: jest.fn(),
  deleteDoc: jest.fn(),
  doc: jest.fn(),
}));

jest.mock("@/firebaseConfig", () => ({ FIREBASE_DB: {} }));

jest.mock("@react-navigation/native", () => ({
  useIsFocused: () => true,
}));

jest.mock("expo-router", () => ({
  router: { push: jest.fn() },
}));

jest.mock("react-native-toast-message", () => ({
  show: jest.fn(),
}));

const mockPlants = [
  {
    id: "1",
    name: "Samambaia",
    description: "Verde e grande",
    watering: { days: ["Segunda"], time: "08:00" },
  },
];

describe("Tela <FlourishScreen />", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    (getDocs as jest.Mock).mockResolvedValue({
      docs: mockPlants.map((p) => ({
        id: p.id,
        data: () => ({
          name: p.name,
          description: p.description,
          watering: p.watering,
        }),
      })),
    });
  });

  it("deve listar as plantas carregadas do banco", async () => {
    render(<FlourishScreen />);
    expect(await screen.findByText("Samambaia")).toBeTruthy();
  });

  it("deve filtrar as plantas ao digitar na busca", async () => {
    render(<FlourishScreen />);

    const inputBusca = await screen.findByPlaceholderText("Buscar");
    fireEvent.changeText(inputBusca, "Cacto");

    await waitFor(() => {
      expect(screen.queryByText("Samambaia")).toBeNull();
    });
  });

  it("deve excluir uma planta ao clicar no ícone de lixeira", async () => {
    (deleteDoc as jest.Mock).mockResolvedValueOnce(undefined);

    render(<FlourishScreen />);

    await screen.findByText("Samambaia");

    const botoesExcluir = screen.getAllByTestId("btn-delete");
    fireEvent.press(botoesExcluir[0]);

    await waitFor(() => {
      expect(deleteDoc).toHaveBeenCalled();
      expect(Toast.show).toHaveBeenCalledWith(
        expect.objectContaining({ text1: "Planta excluida com sucesso" }),
      );
    });
  });
});
