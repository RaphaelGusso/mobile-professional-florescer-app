import UpdatePlant from "@/app/(protected)/flourish/update";
import {
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react-native";
import { router } from "expo-router";
import { getDoc, updateDoc } from "firebase/firestore";
import React from "react";
import Toast from "react-native-toast-message";

jest.setTimeout(15000);

jest.mock("firebase/auth", () => ({
  getAuth: jest.fn(() => ({
    currentUser: { uid: "usuario-teste-123" },
  })),
}));

jest.mock("firebase/firestore", () => ({
  __esModule: true,
  doc: jest.fn(),
  getDoc: jest.fn(),
  updateDoc: jest.fn(),
}));

jest.mock("@/firebaseConfig", () => ({
  FIREBASE_DB: {},
}));

const mockGoBack = jest.fn();
jest.mock("expo-router", () => ({
  __esModule: true,
  router: { back: jest.fn() },
  useNavigation: () => ({
    setOptions: jest.fn(),
    goBack: mockGoBack,
  }),
  useLocalSearchParams: jest.fn(() => ({ plantId: "planta-123" })),
}));

jest.mock("@/utils/notifications", () => ({
  requestNotificationPermission: jest.fn(() => Promise.resolve(true)),
  schedulePlantNotifications: jest.fn(() => Promise.resolve()),
}));

jest.mock("react-native-toast-message", () => ({
  show: jest.fn(),
}));

jest.mock("@/components/ui/weekly-watering-picker", () => {
  const { View } = require("react-native");
  return () => <View testID="weekly-picker-mock" />;
});

describe("Tela <UpdatePlant />", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("deve carregar os dados da planta com sucesso ao abrir a tela", async () => {
    (getDoc as jest.Mock).mockResolvedValueOnce({
      exists: () => true,
      data: () => ({
        name: "Samambaia",
        description: "Fica na varanda",
        watering: { days: [1, 3], time: "10:00" },
      }),
    });

    render(<UpdatePlant />);

    await waitFor(() => {
      expect(screen.getByDisplayValue("Samambaia")).toBeTruthy();
      expect(screen.getByDisplayValue("Fica na varanda")).toBeTruthy();
    });
  });

  it("deve exibir um erro e voltar se a planta não existir no banco", async () => {
    (getDoc as jest.Mock).mockResolvedValueOnce({
      exists: () => false,
    });

    render(<UpdatePlant />);

    await waitFor(() => {
      expect(Toast.show).toHaveBeenCalledWith({
        type: "error",
        text1: "Planta não encontrada",
      });
      expect(router.back).toHaveBeenCalled();
    });
  });

  it("deve atualizar os dados da planta com sucesso ao clicar em Atualizar", async () => {
    (getDoc as jest.Mock).mockResolvedValueOnce({
      exists: () => true,
      data: () => ({
        name: "Cacto",
        description: "Pouca água",
        watering: { days: [], time: "08:00" },
      }),
    });

    (updateDoc as jest.Mock).mockResolvedValueOnce(undefined);

    render(<UpdatePlant />);

    await waitFor(() => {
      expect(screen.getByDisplayValue("Cacto")).toBeTruthy();
    });

    fireEvent.changeText(
      screen.getByPlaceholderText("Nome da planta"),
      "Mini Cacto",
    );

    fireEvent.press(screen.getByText("Atualizar"));

    await waitFor(() => {
      expect(updateDoc).toHaveBeenCalled();
      expect(Toast.show).toHaveBeenCalledWith({
        type: "success",
        text1: "Planta Mini Cacto atualizada!",
      });
      expect(router.back).toHaveBeenCalled();
    });
  });

  it("deve exibir erro de validação se tentar salvar apagando os campos obrigatórios", async () => {
    (getDoc as jest.Mock).mockResolvedValueOnce({
      exists: () => true,
      data: () => ({
        name: "Orquídea",
        description: "Flor",
        watering: { days: [], time: "08:00" },
      }),
    });

    render(<UpdatePlant />);

    await waitFor(() => {
      expect(screen.getByDisplayValue("Orquídea")).toBeTruthy();
    });

    fireEvent.changeText(screen.getByPlaceholderText("Nome da planta"), "");

    fireEvent.press(screen.getByText("Atualizar"));

    expect(Toast.show).toHaveBeenCalledWith({
      type: "error",
      text1: "Preencha todos os campos",
    });
  });
});
