import FlourishDetails from "@/app/(protected)/flourish/[flourishId]";
import {
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react-native";
import { router } from "expo-router";
import { getDoc } from "firebase/firestore";
import React from "react";
import Toast from "react-native-toast-message";

jest.mock("firebase/firestore", () => ({
  __esModule: true,
  doc: jest.fn(),
  getDoc: jest.fn(),
}));

jest.mock("@/firebaseConfig", () => ({
  FIREBASE_DB: {},
}));

jest.mock("@react-navigation/native", () => ({
  useIsFocused: () => true,
}));

const mockGoBack = jest.fn();
jest.mock("expo-router", () => ({
  __esModule: true,
  router: { push: jest.fn() },
  useLocalSearchParams: () => ({ flourishId: "planta-123" }),
  useNavigation: () => ({
    setOptions: jest.fn(),
    goBack: mockGoBack,
  }),
}));

jest.mock("react-native-toast-message", () => ({
  show: jest.fn(),
}));

describe("Tela <FlourishDetails />", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("deve exibir carregamento e depois os detalhes da planta", async () => {
    (getDoc as jest.Mock).mockResolvedValueOnce({
      exists: () => true,
      data: () => ({
        name: "Samambaia",
        description: "Luz indireta",
        watering: { days: ["Segunda", "Sexta"], time: "08:00" },
        photo: null,
      }),
    });

    render(<FlourishDetails />);

    expect(screen.getByText("Carregando dados da planta...")).toBeTruthy();

    await waitFor(() => {
      expect(screen.getByText("Samambaia")).toBeTruthy();
      expect(screen.getByText("Luz indireta")).toBeTruthy();
      expect(screen.getByText(/08:00/)).toBeTruthy();
    });
  });

  it("deve mostrar erro se a planta não for encontrada", async () => {
    (getDoc as jest.Mock).mockResolvedValueOnce({
      exists: () => false,
    });

    render(<FlourishDetails />);

    await waitFor(() => {
      expect(Toast.show).toHaveBeenCalledWith(
        expect.objectContaining({ text1: "Nenhuma planta encontrada!" }),
      );
    });
  });

  it("deve navegar para a tela de edição ao clicar em Editar", async () => {
    (getDoc as jest.Mock).mockResolvedValueOnce({
      exists: () => true,
      data: () => ({
        name: "Cacto",
        description: "Sol pleno",
        watering: { days: ["Domingo"], time: "09:00" },
      }),
    });

    render(<FlourishDetails />);

    await waitFor(() => screen.getByText("Editar"));

    fireEvent.press(screen.getByText("Editar"));

    expect(router.push).toHaveBeenCalledWith(
      "/flourish/update?plantId=planta-123",
    );
  });

  it("deve voltar para a tela anterior ao clicar em Voltar", async () => {
    (getDoc as jest.Mock).mockResolvedValueOnce({
      exists: () => true,
      data: () => ({
        name: "Cacto",
        description: "Sol pleno",
        watering: { days: ["Domingo"], time: "09:00" },
      }),
    });

    render(<FlourishDetails />);

    await waitFor(() => screen.getByText("Voltar"));

    fireEvent.press(screen.getByText("Voltar"));

    expect(mockGoBack).toHaveBeenCalled();
  });
});
