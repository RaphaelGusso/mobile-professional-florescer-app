import * as Notifications from "expo-notifications";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export async function requestNotificationPermission(): Promise<boolean> {
  const { status } = await Notifications.requestPermissionsAsync();
  return status === "granted";
}

export async function schedulePlantNotifications(
  title: string,
  body: string,
  days: string[],
  hour: number,
  minute: number,
  plantId: string
) {
  // getDay() no JS → 0 = domingo ... 6 = sábado
  const dayMap: Record<string, number> = {
    sun: 0,
    mon: 1,
    tue: 2,
    wed: 3,
    thu: 4,
    fri: 5,
    sat: 6,
  };

  for (const day of days) {
    const weekday = dayMap[day];

    const now = new Date();
    const nextTrigger = new Date();

    nextTrigger.setHours(hour);
    nextTrigger.setMinutes(minute);
    nextTrigger.setSeconds(0);
    nextTrigger.setMilliseconds(0);

    const today = now.getDay(); // 0-6
    let daysAhead = weekday - today;

    // Se o dia já passou, manda para a próxima semana
    if (daysAhead < 0) {
      daysAhead += 7;
    }

    nextTrigger.setDate(now.getDate() + daysAhead);

    // Se o horário já passou HOJE, manda para semana seguinte
    if (nextTrigger <= now) {
      nextTrigger.setDate(nextTrigger.getDate() + 7);
    }

    await Notifications.scheduleNotificationAsync({
      content: { title, body, data: { plantId } },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.DATE,
        date: nextTrigger,
      },
    });
  }
}
